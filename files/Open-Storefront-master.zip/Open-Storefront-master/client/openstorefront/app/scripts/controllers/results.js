'use strict';

angular.module('openstorefrontApp')
  .controller('ResultsCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
